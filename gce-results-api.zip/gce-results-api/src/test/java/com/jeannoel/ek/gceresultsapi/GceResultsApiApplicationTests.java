package com.jeannoel.ek.gceresultsapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GceResultsApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
