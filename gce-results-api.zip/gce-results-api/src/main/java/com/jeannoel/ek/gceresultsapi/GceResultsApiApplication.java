package com.jeannoel.ek.gceresultsapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GceResultsApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(GceResultsApiApplication.class, args);
	}

}
